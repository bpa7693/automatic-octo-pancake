//  calls : aide au l'évaluation du nombre d'appels et de la hauteur de pile

#include "calls.h"

static struct {
  unsigned ncalls;
  unsigned hstack_cur;
  unsigned hstack_max;
} calls;

void calls_null(void) {
  calls.ncalls = 0;
  calls.hstack_cur = 0;
  calls.hstack_max = 0;
}

void calls_bgn(void) {
  calls.ncalls += 1;
  calls.hstack_cur += 1;
  if (calls.hstack_cur > calls.hstack_max) {
    calls.hstack_max = calls.hstack_cur;
  }
}

void calls_end(void) {
  calls.hstack_cur -= 1;
}

unsigned calls_get_ncalls(void) {
  return calls.ncalls;
}

unsigned calls_get_hstack_cur(void) {
  return calls.hstack_cur;
}

unsigned calls_get_hstack_max(void) {
  return calls.hstack_max;
}
