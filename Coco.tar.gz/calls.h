//  calls : aide au l'évaluation du nombre d'appels et de la hauteur de pile

#ifndef CALLS_H
#define CALLS_H

//  calls_null : initialise à zéro une variable statique cachée utilisée pour
//    l'évaluation
void calls_null(void);

//  calls_bgn : à faire figurer comme première instruction des sous-programmes à
//    tester
extern void calls_bgn(void);

//  calls_end : à faire figurer comme dernière instruction (hors return) des
//    sous-programmes à tester. Si le sous-programme est une fonction, return
//    doit être suivi d'une expression dans laquelle ne figure aucun appel à un
//    sous-programme
extern void calls_end(void);

//  calls_get_ncalls, calls_get_hstack_cur, calls_get_hstack_max : renvoient
//    le nombre d'appels, la hauteur de pile courante et le maximum des
//    hauteurs de piles comptés depuis de dernier appel à calls_null
extern unsigned calls_get_ncalls    (void);
extern unsigned calls_get_hstack_cur(void);
extern unsigned calls_get_hstack_max(void);

#endif  // CALLS_H
