#include <stdlib.h>
#include <stdio.h>
#include "natnbr_opr.h"
#include "calls.h"

int main(void) {
	natnbr a, b;
  printf("Veuillez entrer deux entiers : ");
	while (scanf("%"NATNBR_SCN "%"NATNBR_SCN, &a, &b) == 2) {
    printf("La somme de %"NATNBR_PRI " et %" NATNBR_PRI " est : %"
            NATNBR_PRI".", a, b, sum(a, b));
    printf(" Nombre d'appels : %u. Pile : %u \n", 
            calls_get_ncalls(), calls_get_hstack_max());
    calls_null();
    printf("La différence de %"NATNBR_PRI " et %" NATNBR_PRI " est : %"
            NATNBR_PRI".", a, b, diff(a, b));
    printf(" Nombre d'appels : %u. Pile : %u \n", 
            calls_get_ncalls(), calls_get_hstack_max());
    calls_null();
	}  
	return EXIT_SUCCESS;
}
  
