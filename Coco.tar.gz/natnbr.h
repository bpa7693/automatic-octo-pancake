//  Définitions du type natnbr, de sa valeur maximale, des macroconstantes
//    servant pour le formatage et le déformatage

//  La macroconstante NATNBR peut être définie à la compilation au moyen de
//    l'option -DNATNBR=VALEUR. Les valeurs valides pour VALEUR sont : UCHAR,
//    USHORTINT, UINT, ULONGINT, ULONGLONGINT, UINT8, UINT16, UINT32, UINT64 et
//    UINTMAX. Ces valeurs correspondent à certaines des possibilités offertes
//    par le langage C quant au codage des entiers signés. Si la macroconstante
//    NATNBR n'est pas définie à la compilation, c'est la valeur UINT qui est
//    prise par défaut

#ifndef NATNBR_H
#define NATNBR_H

#define UCHAR         10
#define USHORTINT     11
#define UINT          12
#define ULONGINT      13
#define ULONGLONGINT  14
#define UINT8         20
#define UINT16        21
#define UINT32        22
#define UINT64        23
#define UINTMAX       30

#ifndef NATNBR
#define NATNBR UINT
#endif

#include <inttypes.h>
#include <limits.h>

#if NATNBR == UCHAR

typedef unsigned char natnbr;

#define NATNBR_MAX UCHAR_MAX
#define NATNBR_PRI "hhu"
#define NATNBR_SCN "hhu"

#elif NATNBR == USHORTINT

typedef unsigned short natnbr;

#define NATNBR_MAX USHRT_MAX
#define NATNBR_PRI "hu"
#define NATNBR_SCN "hu"

#elif NATNBR == UINT

typedef unsigned int natnbr;

#define NATNBR_MAX UINT_MAX
#define NATNBR_PRI "u"
#define NATNBR_SCN "u"

#elif NATNBR == ULONGINT

typedef unsigned long natnbr;

#define NATNBR_MAX ULONG_MAX
#define NATNBR_PRI "lu"
#define NATNBR_SCN "lu"

#elif NATNBR == ULONGLONGINT

typedef unsigned long long natnbr;

#define NATNBR_MAX ULLONG_MAX
#define NATNBR_PRI "llu"
#define NATNBR_SCN "llu"

#elif NATNBR == UINT8

typedef uint8_t natnbr;

#define NATNBR_MAX UINT8_MAX
#define NATNBR_PRI PRIu8
#define NATNBR_SCN SCNu8

#elif NATNBR == UINT16

typedef uint16_t natnbr;

#define NATNBR_MAX UINT16_MAX
#define NATNBR_PRI PRIu16
#define NATNBR_SCN SCNu16

#elif NATNBR == UINT32

typedef uint32_t natnbr;

#define NATNBR_MAX UINT32_MAX
#define NATNBR_PRI PRIu32
#define NATNBR_SCN SCNu32

#elif NATNBR == UINT64

typedef uint64_t natnbr;

#define NATNBR_MAX UINT64_MAX
#define NATNBR_PRI PRIu64
#define NATNBR_SCN SCNu64

#elif NATNBR == UINTMAX

typedef uintmax_t natnbr;

#define NATNBR_MAX UINTMAX_MAX
#define NATNBR_PRI PRIuMAX
#define NATNBR_SCN SCNuMAX

#else
#error bad value for NATNBR
#endif

#endif  // NATNBR_H
