//  Définitions de fonctions binaires sur le type natnbr

#include "natnbr_opr.h"
#include <stdio.h>
#include "calls.h"

natnbr sum(natnbr a, natnbr b) {
  calls_bgn();
  natnbr r;
  if (a == 0) {
    r = b;
  } else {
    r = sum(a - 1, b + 1);
  }
  calls_end();
  return r;
}

natnbr diff(natnbr a, natnbr b) {
  calls_bgn();
  natnbr r;
	if (b == 0) {
		r = a;
	} else {
		r = diff(a - 1, b - 1);	
  }
  calls_end();
  return r;
}

natnbr min(natnbr a, natnbr b) {
  calls_bgn();
  natnbr r;
	if (a == 0) {
		r = a;
	} else if (b == 0) {
		r = b;
	} else {
		r = min(a - 1, b - 1) + 1;
	}
  calls_end();
  return r;
}

natnbr max(natnbr a, natnbr b) {
  calls_bgn();
  natnbr r;
  if (a == 0) {
    r = b;
  } else if (b == 0) {
    r = a;
  } else {
    r = max(a - 1, b - 1) + 1;
  }
  calls_end();
  return r;
}

bool is_eq(natnbr a, natnbr b) {
  calls_bgn();
  bool r;
  if (a == 0) {
    r = (b == 0);
  } else if (b == 0) {
    r = (a == 0);
  } else {
    r = is_eq(a - 1, b - 1);
  }
  calls_end();
  return r;
}


bool is_gth(natnbr a, natnbr b) {
  calls_bgn();
  bool r;
  if (b == 0) {
    r = (b == 0);
  } else { 
    if (a == 0) {
      r = (a == 0);
    } else {
      r = is_gth((a - 1), (b - 1));
    }
  }
  calls_end();
  return r;
}
  
bool is_leq(natnbr a, natnbr b) {
  calls_bgn();
  bool r;
  if (a == 0) {  
    r = (a == 0);
  } else {
    if (b == 0) { 
      r = (b == 0);
    } else {
      r = is_leq((a - 1), (b - 1));
    }
  }
  calls_end();
  return r;
}

bool is_geq(natnbr a, natnbr b) {
  if (b == 0) {  
    return a != 0;
  } else {
    if (a == 0) {
      return a == 0;
    } else {
      return is_geq((a - 1), (b - 1));
    }
  }
}

bool is_lth(natnbr a, natnbr b) {
  calls_bgn();
  bool r;
  if (a == 0) {
    r = (b != 0);
  } else {
    if (b == 0) {
      r = (b == 0);
    } else {
      r = is_lth((a - 1), (b - 1));
    }
  }
  calls_end();
  return r;
}
  
bool is_neq(natnbr a, natnbr b) {
  calls_bgn();
  bool r;
  if (a == 0) {
    r = (b != 0);
  } else {
    r = is_neq((a - 1), (b - 1));
  }
  calls_end();
  return r;
}

natnbr produit(natnbr a, natnbr b) {
  calls_bgn();
  natnbr r;
  if (b == 0) {
    r = 0;
  } else {
    r = a + produit(a, b - 1);
  }
  calls_end();
  return r;
}

natnbr quotient(natnbr a, natnbr b) {
  if (is_geq(b,a)) {
    return 0;
  } else {
    return 1 + quotient(a - b, b);
  }
}

natnbr reste(natnbr a, natnbr b) {
  if (is_geq(b,a)) {
    return a;
  } else {
    return reste(a - b, b);
  }
}
