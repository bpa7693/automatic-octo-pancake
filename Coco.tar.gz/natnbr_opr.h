//  déclarations de fonctions binaires sur le type natnbr

#ifndef NATNBR_OPR_H
#define NATNBR_OPR_H

#include <stdbool.h>
#include "natnbr.h"

extern natnbr sum  (natnbr a, natnbr b);
extern natnbr diff (natnbr a, natnbr b);
extern natnbr min  (natnbr a, natnbr b);
extern natnbr max  (natnbr a, natnbr b);

extern bool is_eq  (natnbr a, natnbr b);
extern bool is_leq (natnbr a, natnbr b);
extern bool is_lth (natnbr a, natnbr b);
extern bool is_neq (natnbr a, natnbr b);
extern bool is_geq (natnbr a, natnbr b);
extern bool is_gth (natnbr a, natnbr b);

extern natnbr quotient (natnbr a, natnbr b);
extern natnbr produit  (natnbr a, natnbr b);
extern natnbr reste    (natnbr a, natnbr b);
	

#endif  // NATNBR_OPR_H
